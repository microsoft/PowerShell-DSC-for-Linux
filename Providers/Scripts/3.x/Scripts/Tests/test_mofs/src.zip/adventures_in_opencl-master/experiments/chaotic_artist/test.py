import 
import wave

wv = wave.Wave()
