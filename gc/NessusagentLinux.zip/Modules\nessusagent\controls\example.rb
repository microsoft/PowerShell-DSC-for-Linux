control 'Service should be installed and running' do
  impact 1.0
  title 'Verify services'
  desc 'Service should be installed and running'
 
    describe service('nessusagent') do
        it { should be_installed }
        it { should be_enabled }
        it { should be_running }
#        its('type') { should be 'systemd' } its ('startmode') { should 
#        be 'Auto'}
    end
end
