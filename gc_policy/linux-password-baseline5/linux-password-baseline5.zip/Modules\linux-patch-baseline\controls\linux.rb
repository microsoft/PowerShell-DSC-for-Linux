
# author: Michael Greene

control 'msid23.2' do
  impact 1.0
  title 'There are no accounts without passwords'
  desc 'An attacker could modify userIDs and login shells'

  describe file('/etc/shadow') do
    its('content') { should_not match "^[^:]+::" }
  end
end
