#--------------------------------------------------------------------------------------------------------------
# Powershell Script that installs the Pull server configuration and Pull server compliance configuration
#--------------------------------------------------------------------------------------------------------------
[CmdletBinding()]
Param( 
        [Int]$Port =8080,
        [switch]$DSCServiceSetup =$False,
        [Int]$CompliancePort =7070,
        [String]$iisroot ="$env:HOMEDRIVE\inetpub\wwwroot",
        [String]$rootdatapath ="$env:PROGRAMFILES\WindowsPowerShell\DscService",
        [switch]$InstallComplianceServer =$True
	 ) 

#
# OS Version
#
$os = [System.Environment]::OSVersion.Version
$blue = $False;
if($os.Major -eq 6 -and $os.Minor -eq 3)
{
    $blue = $True;
}

#
# Source files
#
$pathPullServer     = "$pshome\modules\PSDesiredStateConfiguration\PullServer"

#
# Commands to do the actual installation
#
$scriptDir          = Split-Path $MyInvocation.MyCommand.Path
Import-Module $scriptDir\PSWSIISEndpoint.psm1 -force

#
# Default and calculated values
#
$siteName           = "PSDSCPullServer"
$iisPullServer      = Join-Path $iisroot $siteName

$complianceSiteName = "PSDSCComplianceServer"
$iisComplianceServer= Join-Path $iisroot $complianceSiteName

$configurationpath  = Join-Path $rootdatapath "Configuration"
$modulepath         = Join-Path $rootdatapath "Modules"

$jet4provider       = "System.Data.OleDb"
$jet4database       = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=$env:PROGRAMFILES\WindowsPowerShell\DscService\Devices.mdb;"

$eseprovider        = "ESENT";
$esedatabase        = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Devices.edb";

$language           = "en";

#
# Install the DSC feature if specified
#
if($DSCServiceSetup)
{
    # Install DSC pull service feature
    Add-WindowsFeature Dsc-Service
    Add-WindowsFeature Web-Windows-Auth
    Add-WindowsFeature Web-IP-Security
}

#
# Figure out the language either qps (ps) or en currently
#

$muiPath = Join-Path $pathPullServer "qps-ploc"
if (Test-Path $muiPath)
{
    $language = "qps-ploc";
}                       

#
# Create the basic pull server endpoint
#
Create-PSWSEndpoint     -site $siteName `
                        -path $iisPullServer `
                        -cfgfile "$pathPullServer\PSDSCPullServer.config" `
                        -port $Port `
                        -applicationPoolIdentityType LocalSystem `
                        -app $siteName `
                        -svc "$pathPullServer\PSDSCPullServer.svc" `
                        -mof "$pathPullServer\PSDSCPullServer.mof" `
                        -dispatch "$pathPullServer\PSDSCPullServer.xml" `
                        -asax "$pathPullServer\Global.asax" `
                        -dependentBinaries  "$pathPullServer\Microsoft.Powershell.DesiredStateConfiguration.Service.dll" `
                        -language $language `
                        -dependentMUIFiles  "$pathPullServer\$language\Microsoft.Powershell.DesiredStateConfiguration.Service.Resources.dll"

#
# Create the application data directory calculated above
#
New-Item -path $rootdatapath -itemType "directory" -Force

#
# Set values into the web.config that define the repository and where
# configuration and modules files are stored. Also copy an empty database
# into place.
#
# On Blue always use ESE (Jet Blue). All other platforms use MDB (Jet Red).

if($blue)
{
    Set-Webconfig-AppSettings `
                                -path $iisPullServer `
                                -key "dbprovider" `
                                -value $eseprovider

    Set-Webconfig-AppSettings `
                                -path $iisPullServer `
                                -key "dbconnectionstr" `
                                -value $esedatabase
}
else
{
    Set-Webconfig-AppSettings `
                                -path $iisPullServer `
                                -key "dbprovider" `
                                -value $jet4provider

    Set-Webconfig-AppSettings `
                                -path $iisPullServer `
                                -key "dbconnectionstr" `
                                -value $jet4database
}

$repository = Join-Path $rootdatapath "Devices.mdb"
Copy-Item "$pathPullServer\Devices.mdb" $repository -Force

New-Item -path "$configurationpath" -itemType "directory" -Force

#Provision web.config with Configuration mof repository
Set-Webconfig-AppSettings `
                            -path $iisPullServer `
                            -key "ConfigurationPath" `
                            -value $configurationpath

New-Item -path "$modulepath" -itemType "directory" -Force

#Provision web.config with Modules repository
Set-Webconfig-AppSettings `
                            -path $iisPullServer `
                            -key "ModulePath" `
                            -value $modulepath
#Provision web.config with Pull client (Agent) Registration Key path
Set-Webconfig-AppSettings `
                                    -path $iisPullServer `
                                    -key "RegistrationKeyPath" `
                                    -value $rootdatapath
#
# Used for testing
#
Set-Webconfig-AppSettings `
                            -path $iisPullServer `
                            -key "ApplicationBase" `
                            -value $iispullserver

Set-Webconfig-AppSettings `
                            -path $iisPullServer `
                            -key "TestConfigPath" `
                            -value $iispullserver

#
# Install the admin endpoint if specified
#
if($InstallComplianceServer)
{
    #
    # Create the endpoint
    #
    Create-PSWSEndpoint         -site $complianceSiteName `
                                -path $iisComplianceServer `
                                -cfgfile "$pathPullServer\PSDSCComplianceServer.config" `
                                -port $CompliancePort `
                                -applicationPoolIdentityType LocalSystem `
                                -app $complianceSiteName `
                                -svc "$pathPullServer\PSDSCComplianceServer.svc" `
                                -mof "$pathPullServer\PSDSCComplianceServer.mof" `
                                -asax "$pathPullServer\Global.asax" `
                                -dispatch "$pathPullServer\PSDSCComplianceServer.xml" `
                                -dependentBinaries  "$pathPullServer\Microsoft.Powershell.DesiredStateConfiguration.Service.dll" `
                                -language $language `
                                -dependentMUIFiles  "$pathPullServer\$language\Microsoft.Powershell.DesiredStateConfiguration.Service.Resources.dll"

    #
    # Set values into the web.config that define the repository.
    #

    if($blue)
    {
        Set-Webconfig-AppSettings `
                                    -path $iisComplianceServer `
                                    -key "dbprovider" `
                                    -value $eseprovider

        Set-Webconfig-AppSettings `
                                    -path $iisComplianceServer `
                                    -key "dbconnectionstr" `
                                    -value $esedatabase
    }
    else
    {
        Set-Webconfig-AppSettings `
                                    -path $iisComplianceServer `
                                    -key "dbprovider" `
                                    -value $jet4provider

        Set-Webconfig-AppSettings `
                                    -path $iisComplianceServer `
                                    -key "dbconnectionstr" `
                                    -value $jet4database
    }

    #
    # Used for testing
    #
    Set-Webconfig-AppSettings `
                                -path $iisComplianceServer `
                                -key "ApplicationBase" `
                                -value $iispullserver

    Set-Webconfig-AppSettings `
                                -path $iisComplianceServer `
                                -key "TestConfigPath" `
                                -value $iispullserver

    #
    # Set values into the web.config that indicate this is the admin endpoint.
    #
    Set-Webconfig-AppSettings `
                                -path $iisComplianceServer `
                                -key "AdminEndPoint" `
                                -value "true"
}

