﻿#Region './prefix.ps1' 0
Set-StrictMode -Version latest
$ErrorActionPreference = 'Stop'
$ReleaseVersion = '0.0.0'
#EndRegion './prefix.ps1' 4
#Region './Private/Get-GuestConfigPath.ps1' 0
function Get-GuestConfigPath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    $platform = Get-OSPlatform

    if ($platform -eq 'Windows')
    {
        Join-path -Path $env:ProgramData -ChildPath 'GuestConfig'
    }
    else
    {
        '/var/lib/GuestConfig'
    }
}
#EndRegion './Private/Get-GuestConfigPath.ps1' 18
#Region './Public/Get-DscLibPath.ps1' 0
function Get-DscLibPath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    $gcBinPath = Get-GuestConfigBinaryPath
    if ($(Get-OSPlatform) -eq 'Windows')
    {
        Join-Path -Path $gcBinPath -ChildPath 'gclib.dll'
    }
    else
    {
        Join-Path -Path $gcBinPath -ChildPath 'libgclib.so'
    }
}
#EndRegion './Public/Get-DscLibPath.ps1' 17
#Region './Public/Get-GuestConfigBinaryPath.ps1' 0
function Get-GuestConfigBinaryPath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidGlobalVars', '')]
    param ()

    $binRootFolder = Get-GuestConfigBinaryRootPath
    $releaseVersionfolder = Join-Path -Path $binRootFolder -ChildPath $global:ReleaseVersion
    $guestConfigBinaryPath = Join-Path -Path $releaseVersionfolder -ChildPath 'GC'
    Write-Debug -Message "Guest Config Binary Path is: '$guestConfigBinaryPath'."

    $guestConfigBinaryPath
}
#EndRegion './Public/Get-GuestConfigBinaryPath.ps1' 15
#Region './Public/Get-GuestConfigBinaryRootPath.ps1' 0

function Get-GuestConfigBinaryRootPath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    Join-Path -Path (Get-GuestConfigPath) -ChildPath 'bin'
}
#EndRegion './Public/Get-GuestConfigBinaryRootPath.ps1' 10
#Region './Public/Get-GuestConfigPolicyPath.ps1' 0
function Get-GuestConfigPolicyPath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    Join-path -Path $(Get-GuestConfigPath) -ChildPath 'policy'
}
#EndRegion './Public/Get-GuestConfigPolicyPath.ps1' 9
#Region './Public/Get-GuestConfigurationModulePath.ps1' 0
function Get-GuestConfigurationModulePath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    (Get-Item -Path (Join-Path -Path $PSScriptRoot -ChildPath '..')).Parent.FullName
}
#EndRegion './Public/Get-GuestConfigurationModulePath.ps1' 9
#Region './Public/Get-InspecProfilePath.ps1' 0
function Get-InspecProfilePath
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    Join-Path -Path $(Get-GuestConfigBinaryPath) -ChildPath 'inspec'
}
#EndRegion './Public/Get-InspecProfilePath.ps1' 9
#Region './Public/Get-OSPlatform.ps1' 0
function Get-OSPlatform
{
    [CmdletBinding()]
    [OutputType([System.String])]
    param ()

    $platform = 'Windows'

    if ($PSVersionTable.PSEdition -eq 'Desktop')
    {
        $platform = 'Windows'
    }
    elseif ($PSVersionTable.PSEdition -eq 'Core')
    {
        if ($IsWindows)
        {
            $platform = 'Windows'
        }
        elseif ($IsLinux)
        {
            $platform = 'Linux'
        }
        elseif ($IsMacOS)
        {
            $platform = 'MacOS'
        }
    }

    $platform
}
#EndRegion './Public/Get-OSPlatform.ps1' 31
#Region './Public/InitReleaseVersionInfo.ps1' 0

function InitReleaseVersionInfo
{
    [CmdletBinding()]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidGlobalVars', '')]
    param (
        [Parameter(Mandatory = $true)]
        [System.String]
        $Version
    )

    $global:ReleaseVersion = $Version
}
#EndRegion './Public/InitReleaseVersionInfo.ps1' 14
