//-------------------------------------------------------------------
//
// <company>Microsoft Corporation</company>
//
// <copyright>Copyright (c) Microsoft Corporation 2003</copyright>
//
// <summary>
// Unit test.
// </summary>
// 
// <history>
//   <record date="05-Mar-03">Ported from sample</record>
// </history>
//
//-------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Threading;
using System.Text.RegularExpressions;

using Infra.Frmwrk;

//These classes are only used for the unit tests, so there's no reason to have
//XML comments. Disable the warning, restore at the end of the file.
#pragma warning disable 1591

namespace UnitTest
{
    #region POSITIVES
    public class MyGroup1 : ISetup 
    {
        public void Setup(IContext ctx) {
            IGroupContext gctx = (IGroupContext)ctx;
            string gid = gctx.GroupID;
        }
    }

    public  class MyGroup2 : ISetup, ICleanup 
    {
        public void Setup(IContext ctx) {
        }
        public void Cleanup(IContext ctx) {
        }
    }

    interface IModel1 {
        void  Foo1(IContext ctx);
        void  Foo2(IContext ctx);
    }

    // class for verifying storage of variables and expanding of variables in the %var% syntax
    public class ReadVar : ISetup
    {
        IContext mCtx;
        public void PrintVar(IContext ctx)
        {
            foreach (string key in ctx.FncRecords.FindKeys())
            {
                ctx.Alw("'" + key + " " + ctx.FncRecords.FindValue(key) + "'");
            }
        }
        public void PrintStr(string data)
        {
            mCtx.Alw("'str: " + data + "'");
        }
        public void PrintStrContext(IContext ctx)
        {
            string data = ctx.FncRecords.GetValue("data");
            ctx.Alw("'str: " + data + "'");
        }
        public void PrintArray(string[] data)
        {
            foreach (string d in data)
                PrintStr(d);
        }

        //Returns given value, used to test key updating in mcf
        public string RetValue(string value)
        {
            return value;
        }

        //Returns object, used to test casting to string in fnc returns
        public Type RetObject()
        {
            return GetType();
        }

        public Type RetNullObject()
        {
            return null;
        }

        public object[] RetSubset(object[] original)
        {
            List<object> generated = new List<object>();
            foreach (object e in original)
            {
                if (mCtx.Framework.NextInt(0, 2) > 0)
                    generated.Add(e);
            }
            return generated.ToArray();
        }
        public List<int> Range(int start, int end)
        {
            List<int> result = new List<int>();
            for (int i = start; i < end; i++)
            {
                result.Add(i);
            }
            return result;
        }

        public float Average(float[] numbers)
        {
            float sum = 0;
            foreach (float num in numbers)
                sum += num;
            return sum / numbers.Length;
        }

        public void LogConnection(System.Data.SqlClient.SqlConnection conn)
        {
            mCtx.Alw(conn.ConnectionString);
        }

        public void Setup(IContext ctx)
        {
            mCtx = ctx;
        }
        public ApartmentState ApartmentMode
        {
            get
            {
                return Thread.CurrentThread.GetApartmentState();
            }
        }
    }

    public class MethodsClass : ISetup
    {
        IContext mCtx;
        public void Setup(IContext ctx)
        {
            mCtx = ctx;
        }

        private void PrivateParams(string data)
        {
        }
        private void PrivateContext(IContext ctx)
        {
        }
        private void PrivateEmpty()
        {
        }

        public void PrintA(IContext ctx)
        {
            foreach(string value in ctx.FncRecords.GetValues("key"))
            {
                ctx.Alw("IContext read: " + value);
            }
        }
        public void PrintA(string[] key)
        {
            foreach (string value in key)
            {
                mCtx.Alw("multi read: " + value);
            }
        }
        public void PrintA(string key)
        {
            mCtx.Alw("single read: " + key);
        }
        public void PrintB(string key)
        {
            mCtx.Alw("single read: " + key);
        }
        public void PrintB(string[] key)
        {
            foreach (string value in key)
            {
                mCtx.Alw("multi read: " + value);
            }
        }
    }

    public class ContextLess
    {
        public void Initialize()
        {

        }

        public int ThrowDivideByZero(int num)
        {
            int divisor = 0;
            return num / divisor;
        }
    }

    public class Failures : ISetup
    {
        IContext mCtx;
        public void Setup(IContext ctx)
        {
            ctx.OnErrorContinue = true;
            mCtx = ctx;
        }
        public void PrintStr(string data)
        {
            mCtx.Alw("'str: " + data + "'");
        }
        public void ThrowFail()
        {
            throw new VarFail("Message should be displayed and then continue");
        }

        //This function will be called via reflection
        public void ThrowFail(string param1, string param2)
        {
            throw new VarFail("Message should be displayed and then continue");
        }

        public void ThrowAbort()
        {
            throw new VarAbort("Message should stop execution");
        }

        public void NullReference()
        {
            string temp = null;
            mCtx.Alw(temp.ToString());
        }

        //This function will be called via reflection
        public void NullReference(string param1, string param2)
        {
            string temp = null;
            mCtx.Alw(temp.ToString());
        }

        public void ThrowFailWithInner()
        {
            try
            {
                ThrowAbort();
            }
            catch (VarAbort e)
            {
                throw new VarFail("Failing because caught abort", e);
            }
        }

        public void ThrowWithStackTrace(string param)
        {
            ThrowFailWithInner();
        }

        public void ThrowGrpAbort()
        {
            throw new GroupAbort();
        }

        //Throw an exception that is only availabe by referencing System.Web.Services
        //(which is not referenced by MCF)
        public void ThrowUncommon()
        {
            throw new System.Web.Services.Protocols.SoapException();
        }

        public void ThrowUnsupported()
        {
            throw new VarUnsupported();
        }
    }

    public class HandleFailure : Failures, ICleanup
    {
        public void Cleanup(IContext ctx)
        {
            if (((IVarContext)ctx).Failed)
            {
                ctx.Alw("At least one error occured");
            }
            else
            {
                ctx.Alw("No errors occured");
            }
        }
    }

    // class for verifying regular expression generation
    public class RegExMethods : ISetup
    {
        IContext mCtx;
        public void VerifyRegEx(string value, string regex)
        {
            Regex rxSearch = new Regex(regex);
            if (!rxSearch.Match(value).Success)
            {
                throw new VarFail("value " + value + " did not match " + regex);
            }
            else
            {
                mCtx.Alw("Generated " + value);
            }
        }
        public void Neg_VerifyRegEx(string value, string regex)
        {
            Regex rxSearch = new Regex(regex);
            if (rxSearch.Match(value).Success)
            {
                throw new VarFail("value " + value + " matches " + regex);
            }
            else
            {
                mCtx.Alw("Generated " + value);
            }
        }

        #region ISetup Members

        public void Setup(IContext ctx)
        {
            ctx.WriteMetaData("OS", System.Environment.OSVersion.ToString());
            ctx.WriteMetaData("MachineName", System.Environment.MachineName);
            mCtx = ctx;
        }

        #endregion
    }

    // verify calling functions with no parameters from xml
    public class MyVarVoidMethods
    {
        public MyVarVoidMethods() {}

        public static void VoidStatic() 
        {
            Console.WriteLine("### VoidStatic ###");
            Console.WriteLine(Environment.CommandLine);
        }

        public void VoidInstance() 
        {
            Console.WriteLine("### VoidInstance ###");
            Console.WriteLine(Environment.CommandLine);
        }
    }

    public class MyVarTraversal : IRun, IModel1 
    {
        public MyVarTraversal() 
        {
        }

        public void Run(IContext ctx) {
        }

        public void Foo1(IContext ctx) {
            DumpAll(ctx);
        }

        public void Foo2(IContext ctx) {
            DumpAll(ctx);
        }
        public void Bar1(IContext ctx) {
            DumpAll(ctx);
        }
        static public void Bar2(IContext ctx) {
            ctx.Trc("static Bar2(...)");
            DumpAll(ctx);
            throw new VarFail("Report some failure"); 
        }

        static void DumpAll(IContext ctx) 
        {
            EnumRecs(ctx, ctx.FncRecords, "### FNCRECORDS ###");
            EnumRecs(ctx, ctx.StartStates, "### START STATES ###");
            EnumRecs(ctx, ctx.EndStates, "### STOP STATES ###");
        }

        static public void DumpSubRecords(IContext ctx)
        {
            EnumSubRecs(ctx, ctx.FncRecords, "### FNCRECORDS ###");
            EnumSubRecs(ctx, ctx.Records, "### VARRECORDS ###");
        }

        static void EnumRecs(IContext ctx, IRecords recs, string msg) 
        {
            ctx.Trc(msg);
            foreach(string key in recs.GetKeys())  {
                ctx.Trc(string.Format("Key[{0}]", key));
                // 1:n relation between key and value
                foreach(string val in recs.GetValues(key)) {
                    ctx.Trc(string.Format("     Val[{0}]", val));
                }
            }
        }

        static void EnumSubRecs(IContext ctx, IRecords recs, string msg)
        {
            ctx.Trc(msg);
            foreach (string key in recs.GetKeys())
            {
                ctx.Alw(string.Format("Key[{0}]", key));

                foreach (IRecords subrec in recs.GetSubRecords(key))
                {
                    foreach (string key2 in subrec.GetKeys())
                    {
                        foreach (string val in subrec.GetValues(key2))
                        {
                            ctx.Alw("Key:" + key2 + " Val:" + val);
                        }
                    }
                }
            }
        }
    }

    //Used to print one value from a <recm> with key "CASE"
    public class VarSimplePermute : IRun 
    {
        public void Run(IContext ctx) 
        {   
            string[] keys = ctx.Records.GetKeys();

            foreach (string key in keys)
            {
                ctx.Alw(key + ":" + ctx.Records.GetValue(key));
            }       
        }
    }

    // This will bring down code above if invoked
    // due to non unicode string generated (messed up surrogates)
    public class MyVarSimpleRandomString : IRun 
    {
        public void Run(IContext ctx) 
        {
                string s = ctx.Framework.NextString(".{255}");
                ctx.Framework.Trc(s); // Will throw in StreamWriter.WriteLine
        }
    }

    public class MyVar1 : IRun 
    {
        public void Run(IContext ctx) {
            
            string s = null;
            char [] edges = new char[] {
                '\u0001',
                '\u00FE', 
                '\u00FF',
                '\u0100',
                '\u7FFF',
                '\uFFFF'};
            foreach(char edge in edges) {
                s = ctx.Framework.NextString(new string(edge, 1));
                if(s[0] != edge)
                    throw new VarFail("<<< ### UNIT FAILED ### >>>");
            }

            // TODO: BUGBUG \0 doesn't work
            // s = ctx.Framework.NextString("[^\u10a0]");
            // s = ctx.Framework.NextString("[^\u0000-\u00A7]"); 
            // s = ctx.Framework.NextString("[^\u0001-\u9999]{100,200}"); // throws (hr - incorrect param)
            // s = ctx.Framework.NextString("ABC\u0000DEF"); // chops after \0
            // s = ctx.Framework.NextString("\u0000\u1111\u2222DEF");
            // s = ctx.Framework.NextString("[^\u0000]{100,200}"); // throws (bad hr)
            // s = ctx.Framework.NextString("\u0000");       
            // s = ctx.Framework.NextString("\u0000ABCDEF");  
            
            // Should fail
            // s = ctx.Framework.NextString("{"); 
            // s = ctx.Framework.NextString("\u007B"); // Same as above - '}'

            // TODO: BUGBUG only \u0001-\u8000 is generated
            // if shifted from let's say \u0002- then upto \u8001
            // will be generated

//            long [] stat = new long [0xFFFF+1];
//            s = ctx.Framework.NextString("[\u0001-\uFFFF]{10000000}");  // Distribution
//            foreach(char c in s) {
//                UInt16 i = Convert.ToUInt16(c);
//                stat[i] += 1;
//            }
//
//            stat = new long [0xFFFF+1];
//            for(ulong i = 0; i < 10000000; i++) {
//                UInt16 p = Convert.ToUInt16(ctx.Framework.NextString(".")[0]);
//                stat[p] += 1;
//            }

            // TODO: BUGBUG: This one is even more peculiar:
            // It is hight from 0-255 (39000 average) then from 256-FFFF/2
            // is about 300 then FFFF/2-FFFF it is 0.
//            s = ctx.Framework.NextString(".{10000000}");  // Distribution
//            stat = new long [0xFFFF+1];
//            foreach(char c in s) {
//                UInt16 i = Convert.ToUInt16(c);
//                stat[i] += 1;
//            }

            char [] chars = new char[0xFFFF+1];
            for(int i = 0x00A7; i < 0xFFFF+1; i++) {
                chars[i] = ctx.Framework.NextString((Convert.ToChar(i)).ToString())[0];
            }
            s = new string(chars);

            s = ctx.Framework.NextString("[\u00A0]"); // No break space
            s = ctx.Framework.NextString("[z-\u00A0]{1000}"); // The range includes meta symbols {,|,}
            s = ctx.Framework.NextString("[\u0100-\uFFFF]{10000}");  
            s = ctx.Framework.NextString("[\u1111\u1121\u1211\u2111\u2222]{1000}");  
            s = ctx.Framework.NextString("ABC\u2222");  
//            s = ctx.Framework.NextString(@"");
            s = ctx.Framework.NextString(@".{0}");
            s = ctx.Framework.NextString(@".{0,25}");
            s = ctx.Framework.NextString(@".{1,1}");
            s = ctx.Framework.NextString(@"\w{1,2}");
            s = ctx.Framework.NextString(@"\w{1,2}");
            s = ctx.Framework.NextString(@"\w{0,2}");

            ctx.Comment("DEFAULT TRC COMMENT");
            ctx.StartSection("STuff");
            ctx.Comment(8, "8 - TRC COMMENT");
            ctx.EndSection("STuff");
            ctx.Trc("ctx.Trc(\"IRun.Run(...)\")");
            ctx.Framework.Trc("ctx.Framework.Trc(\"IRun.Run(...)\")");
            throw new VarFail("Report some failure"); 
        }
    }

    public class MyVar2 : ISetup, IRun, ICleanup, IVerify 
    {
        public void Setup(IContext ctx) {
        }
        public void Run(IContext ctx) {
            ctx.Alw("Alw(...)");
            ctx.Err("Err(...)");
            ctx.Wrn("Wrn(...)");
            ctx.Trc("Trc(...)");
        }
        public void Cleanup(IContext ctx) {
        }
        public void Verify(IContext ctx) {
        }
    }
    
    public  class MyVarX : IRun 
    {

        public void Run(IContext ctx) {
            IVarContext vctx = (IVarContext)ctx;
            long s = vctx.Set;
            long l = vctx.Level;
            long v = vctx.VarID;

            foreach(string key in ctx.Records.GetKeys())  {
                ctx.Trc(string.Format("Key[{0}]", key));
                // 1:n relation between key and value
                foreach(string val in ctx.Records.GetValues(key)) {
                    ctx.Trc(string.Format("     Val[{0}]", val));
                }
            }

            ctx.Trc(
                string.Format("R1=[{0}]", ctx.Records.GetValue("R1")));

            string param = "SomeKey";
            if (ctx.Framework.HasKey(param)) {
                ctx.Trc(
                    string.Format("{0} {1}", param, ctx.Framework.GetValue(param)));
            }

            for(int i = 0; i < 10; i++)
                ctx.Trc(ctx.Framework.NextString("[ABCD]{0,10}") );
        }
    }
    

    public class MyVarMultiRun : IMultiResRun
    {
        public MultiRes MultiResRun(IContext ctx) 
        {
            MultiRes res;
            res.VarsAborted = 0;
            res.VarsFailed  = 1;
            res.VarsPassed  = 2;
            res.VarsUnsupported = 3;
            res.VarsNotRun = 4;
            return res;
        }
    }

    public class MyVarRunMultiRun : IRun, IMultiResRun
    {
        public void Run(IContext ctx) {}
        public MultiRes MultiResRun(IContext ctx) 
        {
            MultiRes res = new MultiRes();
            return res;
        }
    }

    public class MyTimeout : IRun
    {        
        public void Run(IContext ctx) 
        {            
            long timeout = ((IVarContext)ctx).Timeout;
            ctx.Framework.Alw("Timeout = "+timeout);
            Thread.Sleep(5);
        }
    }

    public enum TestEnum
    {
        one = 1,
        two = 2,
        three = 3
    }

    public class ComplexMethodsClass : ISetup
    {
        private IContext mCtx = null;

        public void Setup(IContext ctx)
        {
            mCtx = ctx;
        }

        public virtual void VirtualMethod()
        {
            mCtx.Alw("Executing base class method");
        }

        public void EnumMethod(TestEnum tenum)
        {
            mCtx.Alw(tenum.ToString());
            mCtx.Alw("Integer value of enum: " + (int)tenum);
        }

        public void ComplexMethod(bool boolValue, byte byteValue, sbyte SByteValue, char charValue, decimal decimalValue, 
                    double doubleValue, float floatValue, int intValue, uint UIntValue, long longValue,
                    ulong ULongValue, short shortValue, ushort UShortValue, string str, DateTime dateValue,
                    string[] stringArray, int[] integerArray, IContext ctx)
        {
            ctx.Alw("Passed simple type values: ");
            ctx.Alw(boolValue.ToString());
            ctx.Alw(byteValue.ToString());
            ctx.Alw(SByteValue.ToString());
            ctx.Alw(charValue.ToString());
            ctx.Alw(decimalValue.ToString());
            ctx.Alw(doubleValue.ToString());
            ctx.Alw(floatValue.ToString());
            ctx.Alw(intValue.ToString());
            ctx.Alw(UIntValue.ToString());
            ctx.Alw(longValue.ToString());
            ctx.Alw(ULongValue.ToString());
            ctx.Alw(shortValue.ToString());
            ctx.Alw(UShortValue.ToString());
            ctx.Alw(str);
            ctx.Alw(dateValue.ToString());

            ctx.Alw("Passed array values");

            foreach (string val in stringArray)
                ctx.Alw(val);

            foreach (int val in integerArray)
                ctx.Alw(val.ToString());
        }
    }

    public class ComplexMethodsClassOverride : ComplexMethodsClass, ISetup
    {
        private IContext mCtx = null;

        public void Setup(IContext ctx)
        {
            mCtx = ctx;
            base.Setup(ctx);
        }

        public override void VirtualMethod()
        {
            mCtx.Alw("Executing derived class method");
            base.VirtualMethod();
        }
    }

    public class BaseClassWithTypeParameter<TYPE1>
    {
        public void BaseClassMethod(IContext ctx)
        {
            //IL parsing code needs to supply type1 in order 
            //to find the method from its metadata token
            //see http://msdn.microsoft.com/en-us/library/ms145421(VS.96).aspx
            this.Func(ctx); 
        }

        public void Func(IContext ctx)
        {
            ctx.Alw("Method in base class with type parameters");
        }
    }

    public class DerivedClassWithTypeParameter : BaseClassWithTypeParameter<TimeSpan>
    {
        public void DerivedClassMethod(IContext ctx)
        {
            //IL parsing code needs to supply "string" type in order 
            //to find the method from its metadata token
            //see http://msdn.microsoft.com/en-us/library/ms145421(VS.96).aspx
            GenericMethod<string>("param1", ctx);
        }

        public void GenericMethod<TYPE>(TYPE param1, IContext ctx)
        {
            ctx.Alw(param1.ToString());
        }
    }

    public class SampleModel : ISetup
    {
        private IContext mCtx = null;
        private string classVariable = "abc";
        private static string staticVariable = "abc";

        public void Setup(IContext ctx)
        {
            mCtx = ctx;
        }

        public void PrintValues(string param1, int param2)
        {
            McfMethod.Parameter(0, () => mCtx.Framework.NextString("abc|def|ghi"));
            McfMethod.Parameter(1, () => mCtx.Framework.NextInt(100));

            mCtx.Alw(String.Format("Param1 value: {0} Param2 value: {1}", param1, param2.ToString()));
        }

        public void MethodWithRequirement(string param1)
        {
            McfMethod.Parameter(0, () => mCtx.Framework.NextString("abc|def|ghi"));
            McfMethod.Requires(() => !String.IsNullOrEmpty(param1));

            mCtx.Alw(String.Format("Param1 value: {0}", param1));
        }

        public void MethodWithRequirement2(string param1)
        {
            McfMethod.Parameter(0, () => mCtx.Framework.NextString("abc|def|ghi"));
            McfMethod.Requires(() => param1 == classVariable);
            McfMethod.Requires(() => param1 == staticVariable);
            McfMethod.Requires(() => classVariable == staticVariable);
            McfMethod.Requires(() => param1 != null && mCtx.UserObject.GetType().Equals(this.GetType()));

            mCtx.Alw(String.Format("Param1 value: {0}", param1));
        }

        //Delegate for param1 references param2
        public void MethodWithRequirement3(string param1, string param2)
        {
            McfMethod.Parameter(0, () => param2 + "def");
            McfMethod.Parameter(1, () => "abc");

            mCtx.Alw(String.Format("Param1 value: {0} Param2 value: {1}", param1, param2));
        }

        public void MethodWithInvalidParameterValue(string param1)
        {
            McfMethod.Parameter(0, () => McfMethod.InvalidParameterValue);
            mCtx.Alw(String.Format("Param1 value: {0}", param1));
        }

        public void MethodWithNullParameter(string param1)
        {
            McfMethod.Parameter(0, () => null);
            mCtx.Alw(String.Format("Param1 value: {0}", param1 ?? "null"));
        }

        public void MethodWithVerification(string param1, int param2)
        {
            McfMethod.Parameter(0, () => mCtx.Framework.NextString("abc|def|ghi"));
            McfMethod.Parameter(1, () => mCtx.Framework.NextInt(100));

            PrintValues(param1, param2);

            McfMethod.Verify(() => VerificationMethod(param1));
            McfMethod.Verify(() => FailingVerificationMethod(param2.ToString()));
        }

        public void VerificationMethod(string value)
        {
            mCtx.Alw("Running verification method...");
            mCtx.Alw("Passed value..." + value);
        }

        public void FailingVerificationMethod(string value)
        {
            throw new VarFail("Failure.");
        }

        public void FailingAction(string value)
        {
            McfMethod.Parameter(0, () => "sample");
            throw new VarFail("Failure.");
        }
    }

    public class SamplePhoneModel : ISetup
    {
        enum PhoneState { OnHook, DialTone, Busy, Ringing, Talking };
        PhoneState state;

        private IContext mCtx;

        public void Setup(IContext ctx)
        {
            mCtx = ctx;
        }

        private void TransitionTo(PhoneState newState)
        {
            mCtx.Alw(state + " ==> " + newState);
            state = newState;
        }

        public void HangUp()
        {
            McfMethod.Requires(() => state != PhoneState.OnHook);
            McfMethod.Requires(() => state != PhoneState.Ringing);

            TransitionTo(PhoneState.OnHook);
        }

        public void PickUp()
        {
            McfMethod.Requires(() => state == PhoneState.Ringing || state == PhoneState.OnHook);

            if (state == PhoneState.Ringing)
                TransitionTo(PhoneState.Talking);
            else
                TransitionTo(PhoneState.DialTone);
        }

        public void Dial(bool answer)
        {
            McfMethod.Requires(() => state == PhoneState.DialTone);
            McfMethod.Parameter(0, () => mCtx.Framework.NextBool());

            if (answer)
                TransitionTo(PhoneState.Talking);
            else
                TransitionTo(PhoneState.Busy);
        }

        public void BeCalled()
        {
            if (state == PhoneState.OnHook)
                TransitionTo(PhoneState.Ringing);
        }

    }

    public class HLPNMultiLevel
    {
        public void InitializeInnerMarking(IContext ctx)
        {
            IHLPNContext hCtx = (IHLPNContext)ctx;
            IRecords[] tokens = ctx.FncRecords.GetSubRecords("tokens");
            foreach (IRecords token in tokens)
            {
                int count = Int32.Parse(token.GetValue("General.count"));
                for (int i = 0; i < count; i++)
                {
                    hCtx.AddToken("General", "name=" + (i + 1) + "/" + count, "A");
                }
            }
        }
    }

    #endregion

    #region NEGATIVES 
    public class MyVarMultiRunNeg : IMultiResRun
    {
        public MultiRes MultiResRun(IContext ctx) 
        {
            MultiRes res = new MultiRes();
            res.VarsUnsupported = -13;
            return res;
        }
    }

    public class VarAbort2 : IRun
    {
        public void Run(IContext ctx)
        {
            throw new GroupAbort("Group Abort in run");
        }
    }  

    public class BadGroupWGrpAbort1 : ISetup 
    {
        public void Setup(IContext ctx) {
            throw new GroupAbort("grp abort in setup");
        }
    }

    public class BadGroupWGrpAbort2 : ICleanup 
    {
        public void Cleanup(IContext ctx) {
            throw new GroupAbort("grp abort in cleanup");
        }
    }

    public class BadGroupWGrpAbort3 : ISetup, ICleanup
    {
        public void Setup(IContext ctx) {
            throw new GroupAbort("grp abort in setup");
        }
        public void Cleanup(IContext ctx) {
            throw new GroupAbort("grp abort in cleanup");
        }
    }

    public class BadGroupWVarFail1 : ISetup 
    {
        public void Setup(IContext ctx) {
            throw new VarFail("group IS NOT SUPPOSED to throw varfail or varabort");
        }
    }

    public class BadGroupWVarFail2 : ICleanup 
    {
        public void Cleanup(IContext ctx) {
            throw new VarFail("group IS NOT SUPPOSED to throw varfail or varabort");
        }
    }

    public class BadGroupWDivideByZero1 : ISetup 
    {
        public void Setup(IContext ctx) {
            U.DivideByZero();
        }
    }

    public class BadGroupWDivideByZero2 : ICleanup 
    {
        public void Cleanup(IContext ctx) {
            U.DivideByZero();
        }
    }

    public class BadGroupWDivideByZero3 : ISetup, ICleanup 
    {
        public void Setup(IContext ctx) {
            U.DivideByZero();
        }
        public void Cleanup(IContext ctx) {
            U.DivideByZero();
        }
    }

    public class BadConstructorVar1 : IRun
    {
        public BadConstructorVar1() {
            U.DivideByZero();
        }

        public void Run(IContext ctx) {} // need to trigger instantiation
    }

    public class BadConstructorVar2
    {
        public BadConstructorVar2() {
            U.DivideByZero();
        }

        public void Dummy(IContext ctx) {}
    }

    public class MiscNegativeCasesVar
    {
        #region Customized exception

        struct ErrorItem
        {
            public string Message { get; set; }
            public int ErrorCode { get; set; }
            public string ErrorSource { get; set; }
            public string StackTrace { get; set; }

            public override string ToString()
            {
                return "Message:" + Message + Environment.NewLine
                    + "ErrorCode:" + ErrorCode.ToString() + Environment.NewLine
                    + "ErrorSource:" + ErrorSource + Environment.NewLine
                    + "StackTrace:" + StackTrace;
            }
        }

        class MyCollection : System.Collections.CollectionBase
        {
            public MyCollection()
            {

            }

            public void Add(object obj)
            {
                InnerList.Add(obj);
            }

            public void AddRange(System.Collections.ICollection c)
            {
                InnerList.AddRange(c);
            }
        }

        //This class stands for those exceptions which has collection and extra 
        // information declarations, Such as SqlException,etc
        class MyException : Exception
        {
            public MyCollection Errors { get; private set; }
            public int ErrorCode { get; private set; }
            public string ExtraInformation { get; set; }
            public MyCollection ExtraErrors { get; set; }
            public string NullTest { get; private set; }
            public MyCollection NullCollection { get; private set; }
            public ErrorItem MyData { get; private set; }
            public string EmptyString { get; private set; }
            public string ErroredProperty 
            {
                get
                {
                    throw new NullReferenceException("Reference to outside property not accessible");
                }
            }

            public MyException()
            {

            }

            public MyException(string message, int errorCode, MyCollection errors)
                : base(message)
            {
                Errors = new MyCollection();
                Errors.AddRange(errors);
                ErrorCode = errorCode;
                NullTest = null;
                NullCollection = null;
                EmptyString = string.Empty;
                MyData = new ErrorItem { Message = "Inner ErrorItem", StackTrace = "Test", ErrorCode = 0x00004, ErrorSource = "MyException" };
            }
        }

        #endregion

        #region Extended ToString of Exception test

        public void ThrowStandardException(IContext ctx)
        {
            throw new Exception("Standard Exception");
        }

        public void ThrowVarAbort(IContext ctx)
        {
            throw new VarAbort("VarAbort test!");
        }

        public void ThrowVarFail(IContext ctx)
        {
            throw new VarFail("VarFail test!");
        }

        public void ThrowCustomizedException(IContext ctx)
        {
            string message = "This is a test!";
            int errorCode = 0x00005;
            ErrorItem item = new ErrorItem() { ErrorCode = errorCode, StackTrace = "HelloWorld!", Message = message, ErrorSource = "ToStringTest" };
            MyCollection c = new MyCollection();
            c.Add(item);
            MyCollection sc = new MyCollection();
            sc.Add(item);
            sc.Add(item);
            sc.Add(new ErrorItem() { ErrorCode = 0x0003, StackTrace = "Second Collection", Message = "Greetings", ErrorSource = "Second" });
            throw new MyException(message, errorCode, c) { ExtraInformation = "Test Extra information!", ExtraErrors = sc };
        }

        #endregion

        public void ThrowVarUnsupported(IContext ctx) {
            throw new VarUnsupported("VARUNSUPPORTED");
        }
        public void ThrowDivideByZero(IContext ctx) {
            U.DivideByZero();
        }
        public void ThrowNullReference(IContext ctx) {
            throw new NullReferenceException("FAKE NULLREF");
        }
    }

    public class NonFrameworkExceptionInSetup : ISetup
    {
        public void Setup(IContext ctx)
        {
            throw new NullReferenceException("Non-framework exception in setup");
        }
    }

    public class NonFrameworkExceptionInCleanup : ICleanup
    {
         public void Cleanup(IContext ctx)
        {
            throw new NullReferenceException("Non-framework exception in cleanup");
        }
    }

    public class NonFrameworkExceptionInRun : IRun
    {
        public void Run(IContext ctx)
        {
            throw new NullReferenceException("Non-framework exception in run");
        }
    }

    public class NonFrameworkExceptionInVerify : IVerify
    {
        public void Verify(IContext ctx)
        {
            throw new NullReferenceException("Non-framework exception in verify");
        }
    }
    
    public class LongCallHandlerTest : ISetup, IRun, IVerify, ICleanup
    {
        long count;
        const int interval = 100;
        IContext context;

        //Simulates long call
        //A record 'time(ms)' that holds expected execution time can be set
        //A record 'throwEx' indicating whether an exception should be thrown or not.
        public void LongCall(string time, string exType)
        {
            long expectedExecutionTime = long.MaxValue;
            count = 0;

            if (!string.IsNullOrEmpty(time))
                expectedExecutionTime = Int64.Parse(time);

            context.Trc("Execution time:" + expectedExecutionTime);
            context.Trc("User exception type:" + exType);

            while (true)
            {
                if (count >= expectedExecutionTime)
                    break;
                
                System.Threading.Thread.Sleep(interval);
                count += interval;
            }

            if (!string.IsNullOrEmpty(exType)) 
            {
                int exTypeValue = Int32.Parse(exType);
                switch (exTypeValue)
                {
                    case 0:
                         throw new Exception("Simulate throwing exception from user code."); 
                    case 1:
                         throw new ThreadInterruptedException("Simulate throwing ThreadInterruptedException from user code.");
                }    
            }
        }

        public void RegularCall(IContext ctx)
        {
            ctx.Trc("This is a test!");
        }

        #region ISetup Members

        public void Setup(IContext ctx)
        {
            context = ctx;
            CallLongCall(ctx, "Setup_LongCall");
        }

        #endregion

        #region IRun Members

        public void Run(IContext ctx)
        {
            CallLongCall(ctx, "Run_LongCall");
        }

        #endregion

        #region IVerify Members

        public void Verify(IContext ctx)
        {
            CallLongCall(ctx, "Verify_LongCall");
        }

        #endregion

        #region ICleanup Members

        public void Cleanup(IContext ctx)
        {
            //Timeout is based on 500ms. Offset the count by 100 to minimize the randomness.
            long min = Math.Max(0, (count - 100) / 500);
            ctx.Alw("Finished execution between " + 500 * min + "ms, and " + 500 * (min+1) + "ms");
            CallLongCall(ctx, "Cleanup_LongCall");
        }

        #endregion

        private void CallLongCall(IContext ctx, string recordName)
        {
            bool callInfinite = false;

            bool.TryParse(ctx.Records.FindValue(recordName), out callInfinite);

            string time = ctx.Records.GetValue("time");

            if (callInfinite)
                LongCall(time, ctx.Records.GetValue("exType"));
        }
    }
    #endregion

    #region Auxiliary
    class U 
    {
        static internal void DivideByZero() 
        {
                string s = "";
                int i = 5;
                i /= s.Length;
        }
    }
    #endregion
}

#pragma warning restore 1591
