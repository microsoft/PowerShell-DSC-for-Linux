# Specially made script to remove noise from the log diffs
# Noise refers to any changes in the log that result from running at a different time or on
# a different machine rather than changes to MCF.

$previous = $NULL
filter replaceregex
{
  $changed = $_
  $filePathRegex = '\w:\\([^\/:*?"<>|]+\\)*([^\/:*?"<>|]+(\.[^\/:*?"<>|]+)?)?\'
  $machineNameRegex = '[\w|-]+'
  # Remove file paths
  $changed = [Regex]::Replace($changed, $filePathRegex + '(', "#:\...(")
  $changed = [Regex]::Replace($changed, $filePathRegex + ']', "#:\...]")

  # Remove .NET version number
  $changed = [Regex]::Replace($changed, "Runtime Version:\d\.\d\.\d+\.\d+", "Runtime Version:#.#.#.#")
  $changed = [Regex]::Replace($changed, "CLR: loaded \[\d\.\d\.\d+\.\d+\], built for \[v[0-9.]+\]", "CLR: loaded [#.#.#.#], built for [v#]")

  # Remove OS version number
  $changed = [Regex]::Replace($changed, "Microsoft Windows NT \d\.\d\.\d+\.\d+", "Microsoft Windows NT #.#.#.#")

  # Remove machine name (XML store this in multiple lines, so we need to refer to the $previous line)
  $changed = [Regex]::Replace($changed, "MachineName : " + $machineNameRegex, "Machine : #")
  if ($previous -match "<MachineName")
  {
      $changed = [Regex]::Replace($changed, $machineNameRegex, "#")
  }

  $previous = $_
  $changed
}

cat $args[0] | replaceregex > $args[1]