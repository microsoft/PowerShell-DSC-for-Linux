In order to run the unit tests for MCF, checkout the files in the results folder
for editing and run unit.cmd.
PowerShell must be installed in order for the script to run.

Running unit.cmd will copy all MCF files from the mcf\build\Debug directory, and
will then remove all .pdb files from the unittest directory. Having pdb files 
would insert volatile line numbers for testing error output which would make 
confirming the output difficult. Then the test cases are run and the results are 
copied to the results folder. The files in the results folder must be checked 
out for editing before the test is run so that unit.cmd can overwrite them with 
the new results

To confirm that MCF passes the unit test, visually confirm that the log output 
in the results folder is correct. Note that many of the unit tests are 
confirming error output, so errors are expected. The recommended way to confirm 
is to use WinDiff or a similar tool to compare the changes in the log output 
(e.g. sd diff full.xmlf). Note that there will always be some differences 
because some of the test cases measure and output running time and system 
variables.

To use windiff (or similar program) with sd diff, use the commands:
set SDDIFF=windiff.exe
set SDUDIFF=windiff.exe
windiff.exe must be in the PATH

As a seperate optional step, modifying unit.cmd so that CODECOVERAGE=ON will 
generate code coverage numbers for the unit tests (though it will change the 
output, so code coverage cannot be enabled when verifying the unit test 
results). This also requires that performance testing tools be installed for VS. 
After setting the value, run unit.cmd as usual and it will output 
mcf.coverage to the coverage folder along with the necessary binaries and pdbs 
for the results. The results can be opened with any copy of Visual Studio that
has the performance testing tools installed. Multiple results can be compared 
using the vsperfreport.exe command.

Before checking in, make sure that the files in the results folder are correct.