'-------------------------------------------------------------------
'
' company:
'   Microsoft Corporation
'
' summary:
'   VB.Net sample implementation of the framework's plugin classes.
' 
'-------------------------------------------------------------------

Imports System

Imports Infra.Frmwrk

' All classes intended to be invoked by the framework should be defined as public

Namespace Test.SomeComponent

    ' Implements ISetup only (it is optional)
    Public Class MyGroup1
        Implements ISetup

        Public Sub Setup(ByVal ctx As IContext) Implements ISetup.Setup
            ' Accessing group specific context data
            Dim gctx As IGroupContext
            gctx = CType(ctx, IGroupContext)
            Dim gid As String = gctx.GroupID
        End Sub

    End Class

    ' Implements both ISetup and ICleanup (both are optional)
    Public Class MyGroup2
        Implements ISetup
        Implements ICleanup

        Public Sub Setup(ByVal ctx As IContext) Implements ISetup.Setup
        End Sub

        Public Sub Cleanup(ByVal ctx As IContext) Implements ICleanup.Cleanup
        End Sub

    End Class

    ' Report Failure
    Public Class MyVar1
        Implements IRun

        Public Sub Run(ByVal ctx As IContext) Implements IRun.Run
            Throw New VarFail("Report some failure")
        End Sub


    End Class


    ' Implement all - ISetup, IRun, IVerify  or ICleanup (all are optional)
    Public Class MyVar2
        Implements ISetup
        Implements IRun
        Implements IVerify
        Implements ICleanup

        Public mCtx As IContext

        Public Sub Setup(ByVal ctx As IContext) Implements ISetup.Setup
            mCtx = ctx
        End Sub

        Public Sub Run(ByVal ctx As IContext) Implements IRun.Run
        End Sub

        Public Sub Verify(ByVal ctx As IContext) Implements IVerify.Verify
        End Sub

        Public Sub Cleanup(ByVal ctx As IContext) Implements ICleanup.Cleanup
        End Sub

        Public Sub LogDate(ByVal mOffset As Integer, ByVal dOffset As Integer, ByVal format As String)
            Dim msg As DateTime
            msg = DateTime.Now
            msg = msg.AddMonths(mOffset)
            msg = msg.AddDays(dOffset)
            mCtx.Alw(msg.ToString(format))
            mCtx.WriteMetaData("Date", msg.ToString(format))
        End Sub

    End Class


    Public Class MyVar3
        Implements IRun

        Public Sub Run(ByVal ctx As IContext) Implements IRun.Run

            ' Tracing
            ctx.Alw("Alw(...)") ' Level 'Always'
            ctx.Err("Err(...)") ' Level 'Error'
            ctx.Wrn("Wrn(...)") ' Level 'Warning'
            ctx.Trc("Trc(...)") ' Level 'Trace'

            ' Accessing variation specific context data
            Dim vctx As IVarContext
            vctx = CType(ctx, IVarContext)
            Dim s As Long = vctx.Set
            Dim l As Long = vctx.Level
            Dim v As Long = vctx.VarID

            ' Fetching records
            Dim key As String
            For Each key In ctx.Records.GetKeys()
                ctx.Trc("Key[" + key + "]")
                Dim val As String
                ' 1:n relation between key and value
                For Each val In ctx.Records.GetValues(key)
                    ctx.Trc("     Val[" + val + "]")
                Next
            Next
            ' 1:1 relation between key and value
            ctx.Trc("R1=[" + ctx.Records.GetValue("R1") + "]")

            ' Fetching global parameters
            Dim param As String = "SomeKey"
            If (ctx.Framework.HasKey(param)) Then
                ctx.Trc(param + " " + ctx.Framework.GetValue(param))
            End If

            ' Generating random data
            ' String from 1 to 10 characters will be generated containing
            ' random permutation of A, B, C and D characters
            ctx.Trc(ctx.Framework.NextString("[ABCD]{1,10}"))

        End Sub

    End Class

End Namespace