//-------------------------------------------------------------------
///
/// <company>Microsoft Corporation</company>
///
/// <copyright>Copyright (c) Microsoft Corporation 2001</copyright>
///
/// <summary>
///   CSharp sample implementation of the framework's plugin classes & unit test.
/// </summary>
/// 
/// <history>
///   <record date="05-Nov-01">Created</record>
/// </history>
///
//-------------------------------------------------------------------

using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

using Infra.Frmwrk;

// All classes intended to be invoked by the framework should be defined as public
// Each of the classes presented here is independent of the other classes. They are included in a single .cs file in 
// order to simplify compiling

namespace Test.SomeComponent
{

    // This class does not require a reference to MCF. Classes without knowledge of MCF classes can be loaded by MCF,
    // but such classes will not be able to use most features of MCF.
    public class Lvl1
    {
        // Write a given string to the console. Since output is not sent to the MCF logger, the output will not be 
        // saved
        // str - String to be printed to the console
        public void echo(string str)
        {
            Console.WriteLine(str);
        }

        // Returns the current date as a string
        public string GetFormattedDate()
        {
            return DateTime.Now.ToLongDateString();
        }
    }

    // This class is the same as Lvl1, but with methods specifically written for MCF. 
    public class Lvl2
    {
        // Write a given string to the MCF log. 
        // ctx - Provided automatically by MCF. The context of the calling 'fnc' node
        public void echo(IContext ctx)
        {
            //retrieve the method parameter with the name 'str'
            string str = ctx.FncRecords.FindValue("str");

            //write the string to the log. Additional methods are available from IContext to log the string
            //at different levels of importance and visibility.
            ctx.Alw(str);
        }

        // Returns the current date as a string
        public string GetFormattedDate()
        {
            return DateTime.Now.ToLongDateString();
        }
    }

    // A more complex example using ISetup to make the methods simpler
    public class Lvl3 : ISetup
    {
        // For storing the context of the variation. This is sufficient for performing most MCF tasks
        private IVarContext mCtx;

        // Setup is called by MCF at the start of the variation, so it will run before any other methods. In this case
        // it stores the context of the current variation so that other methods can use this context for logging
        // purposes.
        // ctx - Provided automatically by MCF. The context of the variation.
        public void  Setup(IContext ctx)
        {
            //this class should always be associated with a variation
            //in the varmap. Never with a group.
 	        mCtx = (IVarContext)ctx;
        }

        // Write a given string to the MCF log. 
        // str - String to be written to the log
        public void echo(string str)
        {
            mCtx.Alw(str);
        }

        // Returns the current date as a string
        public string GetFormattedDate()
        {
            return DateTime.Now.ToLongDateString();
        }
    }

    // A class to be associated with a 'grp' node. Only Setup and Cleanup methods are run by MCF
    public class Lvl4Grp : ISetup, ICleanup
    {
        public void Setup(IContext ctx)
        {
            ctx.WriteMetaData("Started", DateTime.Now.ToString());
            ctx.WriteMetaData("User", Environment.UserDomainName + "\\" + Environment.UserName);
            ctx.WriteMetaData("OS", Environment.OSVersion.ToString());

            //Define record values for %USER% and %DOMAIN%. These can be accessed by any child groups and variations
            ctx.Records.Add("USER", Environment.UserName);
            ctx.Records.Add("DOMAIN", Environment.UserDomainName);
        }

        public void Cleanup(IContext ctx)
        {
            ctx.WriteMetaData("Ended", DateTime.Now.ToString());
        }
    }

    // A more complex example with methods for basic testing of a website
    public class Lvl4 : ISetup, IRun, IVerify, ICleanup
    {
        private IVarContext mCtx;

        public void Setup(IContext ctx)
        {
            mCtx = (IVarContext)ctx;
        }

        public void Run(IContext ctx)
        {
            mCtx.Alw("Beginning execution");
        }

        public void Verify(IContext ctx)
        {
            mCtx.Alw("Execution finished. Verifying");
        }

        public void Cleanup(IContext ctx)
        {
            if (ctx.Failed)
            {
                ctx.Alw("Errored during execution");
            }
        }

        public void VerifyText(string text, string pattern_rx)
        {
            Regex rxSearch = new Regex(pattern_rx);
            if (!rxSearch.Match(text).Success)
            {
                throw new VarFail("value '" + pattern_rx + "' not found in text");
            }
        }

        public string GetHtml(string url)
        {
            WebClient client = new WebClient();
            client.Credentials = CredentialCache.DefaultNetworkCredentials;
            Stream str = client.OpenRead(url);
            StreamReader sr = new StreamReader(str);
            string html = sr.ReadToEnd();
            mCtx.Trc(html);
            return html;
        }

        public string GetDate(string format, string dateOffset, string timeOffset)
        {
            DateTime date = DateTime.Now;
            if (String.IsNullOrEmpty(format))
            {
                format = "MM\\DD\\YYY";
            }

            if (!String.IsNullOrEmpty(dateOffset))
            {
                string[] dateOffsets = dateOffset.Split('\\');
                if (dateOffsets.Length != 3)
                {
                    throw new ArgumentException(dateOffset + " should have the form #\\#\\# where each '#' is an integer offset");
                }

                date = date.AddMonths(int.Parse(dateOffsets[0]));
                date = date.AddDays(int.Parse(dateOffsets[1]));
                date = date.AddYears(int.Parse(dateOffsets[2]));
            }

            if (!String.IsNullOrEmpty(timeOffset))
            {
                string[] timeOffsets = timeOffset.Split(':');
                if (timeOffsets.Length != 3)
                {
                    throw new ArgumentException(timeOffset + " should have the form #:#:# where each '#' is an offset");
                }

                date = date.AddHours(double.Parse(timeOffsets[0]));
                date = date.AddMinutes(double.Parse(timeOffsets[1]));
                date = date.AddSeconds(double.Parse(timeOffsets[2]));
            }

            mCtx.Trc(date.ToString(format));

            return date.ToString(format);
        }
    }

    // This class exists as a reference to MCF features that are not shown in any of the above example classes
    // There is no varmap using this class
    public  class Reference :
        IRun
    {

        public void Run(IContext ctx)
        {
            // Tracing
            ctx.Alw("Alw(...)"); // Level 'Always'
            ctx.Err("Err(...)"); // Level 'Error'
            ctx.Wrn("Wrn(...)"); // Level 'Warning'
            ctx.Trc("Trc(...)"); // Level 'Trace'

            // Accessing variation specific context data
            IVarContext vctx = (IVarContext)ctx;
            long s = vctx.Set;
            long l = vctx.Level;
            long v = vctx.VarID;

            // Fetching records
            foreach(string key in ctx.Records.GetKeys())
            {
                ctx.Trc(string.Format("Key[{0}]", key));
                // 1:n relation between key and value
                foreach(string val in ctx.Records.GetValues(key))
                {
                    ctx.Trc(string.Format("     Val[{0}]", val));
                }
            }

            // 1:1 relation between key and value
            ctx.Trc(
                string.Format("R1=[{0}]", ctx.Records.GetValue("R1")));

            // Fetching global parameters
            string param = "SomeKey";
            if (ctx.Framework.HasKey(param)) 
            {
                ctx.Trc(
                    string.Format("{0} {1}", param, ctx.Framework.GetValue(param)));
            }

            // Generating random data
            // String from 1 to 10 characters will be generated containing
            // random permutation of A, B, C and D characters
            ctx.Trc(
                ctx.Framework.NextString("[ABCD]{1,10}") );

        } // end of method
    } // end of class

}// end of namespace
