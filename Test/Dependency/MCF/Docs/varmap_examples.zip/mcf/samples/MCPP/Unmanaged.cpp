//-------------------------------------------------------------------
//
// company:
//   Microsoft Corporation
//
// summary:
//   Defining native function
// 
//-------------------------------------------------------------------

#include <stdio.h>

#include "Unmanaged.h"

#pragma unmanaged
extern "C" void __cdecl funcNative(intptr_t hd)
{
    MyTrace(hd);
}

