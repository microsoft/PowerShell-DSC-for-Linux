//-------------------------------------------------------------------
//
// company:
//   Microsoft Corporation
//
// summary:
//   Managed C++ sample implementation of the framework's plugin classes.
// 
//-------------------------------------------------------------------

#include "MCPPPlugin.h"
#include "Unmanaged.h"

using namespace System::Runtime::InteropServices;

// All classes intended to be invoked by the framework should be defined as public

namespace Test {
namespace SomeComponent {

    // Implements ISetup only (it is optional)
    public __gc class MyGroup1 :
        public ISetup
    {
    public:
        void Setup(IContext* ctx)
        {
            // Accessing group specific context data
            IGroupContext* gctx = dynamic_cast<IGroupContext*>(ctx);
            String* pGid = gctx->get_GroupID();
            pGid = pGid; // Silence warning, demo code only
        }

    };

    // Implements both ISetup and ICleanup (both are optional)
    public __gc class MyGroup2 :
        public ISetup,
        public ICleanup
    {
    public:
        void Setup(IContext* ctx)
        {
        }

        void Cleanup(IContext* ctx)
        {
        }
    };


    // Report Failure
    public __gc class MyVar1 :
        public IRun
    {
    public:
        void Run(IContext* ctx)
        {
            throw new VarFail(S"Report some failure in Fail1");
        }

    };


    // Implement all - ISetup, IRun, IVerify  or ICleanup (all are optional)
    public __gc class MyVar2 :
        public ISetup,
        public IRun,
        public ICleanup,
        public IVerify
    {
	private:
		IContext* mCtx;
    public:
        void Setup(IContext* ctx)
        {
			mCtx = ctx;
        }

        void Run(IContext* ctx)
        {
        }

        void Cleanup(IContext* ctx)
        {
        }

        void Verify(IContext* ctx)
        {
        }

		void LogDate(int mOffset, int dOffset, String* format)
        {
			System::DateTime date = System::DateTime::Now;
			date = date.AddMonths(mOffset);
			date = date.AddDays(dOffset);
			mCtx->Alw(date.ToString(format));
			mCtx->WriteMetaData("Date", date.ToString(format));
        }
    };


    public __gc class MyVar3 :
        public IRun
    {
    public:
        void Run(IContext* ctx)
        {
            // Tracing
            ctx->Alw("Alw(...)"); // Level 'Always'
            ctx->Err("Err(...)"); // Level 'Error'
            ctx->Wrn("Wrn(...)"); // Level 'Warning'
            ctx->Trc("Trc(...)"); // Level 'Trace'

            // Accessing variation specific context data
            IVarContext* pVCtx = dynamic_cast<IVarContext*>(ctx);
            long s = pVCtx->get_Set();
            long l = pVCtx->get_Level();
            long v = pVCtx->get_VarID();
            s = l = v = 0; // Silence warning

            // Fetching records
            IEnumerator* keys = ctx->get_Records()->GetKeys()->GetEnumerator();
            while(keys->MoveNext()) 
            {
                String* key = dynamic_cast<String*>(keys->get_Current());
                ctx->Trc(String::Format(S"Key[{0}]", key));
                // 1:n relation between key and value
                IEnumerator* vals = 
                    ctx->get_Records()->GetValues(key)->GetEnumerator();
                while(vals->MoveNext())
                {
                    String* val = dynamic_cast<String*>(vals->get_Current());
                    ctx->Trc(String::Format(S"     Val[{0}]", val));
                }
            }

            // 1:1 relation between key and value
            ctx->Trc(
                String::Format(S"R1=[{0}]", 
                    ctx->get_Records()->GetValue(S"R1")));

            // Generating random data
            // String from 1 to 10 characters will be generated containing
            // random permutation of A, B, C and D characters
            ctx->Trc(
                ctx->get_Framework()->NextString(S"[ABCD]{1,10}") );

            // Calling native code and using managed callback from it
            intptr_t hd = ctx->get_Framework()->GetHandle()
#ifdef _WIN32
                .ToInt32();
#elif defined(_WIN64)
                .ToInt64();
#else
#error ERROR: either _WIN64 or _WIN32 must be defined
#endif

            funcNative(hd); // Calling 'really' native funcntion (No IL here). 
        }
    }; 

} // end of namespace 
} // end of namespace 


extern "C" void __cdecl MyTrace(intptr_t hd)
{
    IFrameworkContext * pFC = 
        static_cast<IFrameworkContext*>(GCHandle::op_Explicit(hd).Target);
    pFC->Alw("Called from native code...");
}