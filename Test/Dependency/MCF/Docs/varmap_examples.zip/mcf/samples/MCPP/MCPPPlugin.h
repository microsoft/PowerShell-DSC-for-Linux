// MCPPPlugin.h

#pragma once

// We need this to reference framework's types (but you do not have to if you do
// not use any - the usefullness of such app. would be questionable but this is separate 
// matter)

#using "MCF.INFRA.TYPES.dll"


using namespace System;
using namespace System::Collections;

// We need this to reference framework's types
using namespace Infra::Frmwrk;
