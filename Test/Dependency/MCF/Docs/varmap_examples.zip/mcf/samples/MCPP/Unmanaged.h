//-------------------------------------------------------------------
//
// company:
//   Microsoft Corporation
//
// summary:
//   Defining native function
// 
//-------------------------------------------------------------------

#include <stddef.h>

#pragma unmanaged
extern "C" void __cdecl funcNative(intptr_t hd);

#pragma managed
extern "C" void __cdecl MyTrace(intptr_t hd);

 